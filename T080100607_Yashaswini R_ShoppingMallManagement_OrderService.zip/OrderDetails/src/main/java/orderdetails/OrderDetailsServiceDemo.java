package orderdetails;
import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class OrderDetailsServiceDemo {
    
	@Autowired
	private OrderDetailsRepositoryDemo repo;
	public List<OrderDemo> listAll()
	{
		return repo.findAll();
	}
	 public void save(OrderDemo orderdetails) 
 {
 repo.save(orderdetails);
 }
 
 public OrderDemo get(Integer id) 
 {
 return repo.findById(id).get();
 }
 
 public void delete(Integer id) 
 {
 repo.deleteById(id);
 }
public static List<OrderDemo> getAllOrders() {
	// TODO Auto-generated method stub
	return null;
}
	
	
}
