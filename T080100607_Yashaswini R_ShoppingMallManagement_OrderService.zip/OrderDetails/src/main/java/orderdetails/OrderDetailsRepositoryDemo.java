package orderdetails;

import org.springframework.data.jpa.repository.JpaRepository;


public interface OrderDetailsRepositoryDemo extends JpaRepository<OrderDemo, Integer> {


}
