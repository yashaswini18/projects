package orderdetails;

public @interface HttpSecurity {



}
